package remainderwebapp;

public class GetSet {
	
	static int uid;
	public static int getUid(){
		return uid;
	}
	public static void  setUid(int uid){
		GetSet.uid=uid;
	}

}
