package remainderwebapp;

public @interface WebServlet {

	String value();

}
